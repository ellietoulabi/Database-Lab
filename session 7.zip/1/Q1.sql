--Session7
--Q1

--in LINUX terminal:
-- /opt/mssql-tools/bin/bcp AdventureWorks2012.Sales.SalesTerritory out /home/ellie/Desktop/7th/1/SalesTerritory.txt -S 127.0.0.1 -U SA -P Ellie1999 -c -t\|

--create table
CREATE TABLE SalesTerritoryNew(
	[TerritoryID] [int] NOT NULL,
	[Name] [dbo].[Name] NOT NULL,
	[CountryRegionCode] [nvarchar](3) NOT NULL,
	[Group] [nvarchar](50) NOT NULL,
	[SalesYTD] [money] NOT NULL,
	[SalesLastYear] [money] NOT NULL,
	[CostYTD] [money] NOT NULL,
	[CostLastYear] [money] NOT NULL,
	[rowguid] [uniqueidentifier] ROWGUIDCOL  NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) 


--insert data into new table
BULK INSERT SalesTerritoryNew
FROM '/home/ellie/Desktop/7th/1/SalesTerritory.txt'
WITH
(
    fieldterminator = '|'
)

--display new table
SELECT * FROM SalesTerritoryNew