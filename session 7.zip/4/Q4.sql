--Session7
--Q4


--query to show the result
select Name,Demographics.query('declare default element namespace "http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/StoreSurvey";for $x in /StoreSurvey return <Result>{$x/AnnualSales} {$x/YearOpened} {$x/NumberEmployees}</Result>')
FROM Sales.Store

--in Linux Terminal or ... :
-- /opt/mssql-tools/bin/bcp "select Name,Demographics.query('declare default element namespace \"http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/StoreSurvey\";for \$x in /StoreSurvey return <Result>{\$x/AnnualSales} {\$x/YearOpened} {\$x/NumberEmployees}</Result>') as data FROM AdventureWorks2012.Sales.Store" queryout /home/ellie/Desktop/7th/4/StoresInfo.txt -S 127.0.0.1 -U SA -P Ellie1999 -c -q -t\|

