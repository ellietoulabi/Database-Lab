--Session7
--Q3

--in LINUX terminal:
-- /opt/mssql-tools/bin/bcp AdventureWorks2012.Production.Location out /home/ellie/Desktop/7th/3/location.dat -S 127.0.0.1 -U SA -P Ellie1999 -c -t\|