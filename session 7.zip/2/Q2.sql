--Session7
--Q2


-- query
SELECT TerritoryID,Name
FROM Sales.SalesTerritory

--due to using Linux (ubuntu 19) I'm not capable of executing xp_cmdshell command because it's not supported in linux but the syntax is :
EXEC xp_cmdshell '/opt/mssql-tools/bin/bcp "SELECT Name,TerritoryID FROM AdventureWorks2012.Sales.SalesTerritory" queryout /home/ellie/Desktop/7th/2/TerritoryInfo.txt -S 127.0.0.1 -U SA -P Ellie1999 -c -q -t\|'


--in linux terminal
--/opt/mssql-tools/bin/bcp "SELECT Name,TerritoryID FROM AdventureWorks2012.Sales.SalesTerritory" queryout /home/ellie/Desktop/7th/2/TerritoryInfo.txt -S 127.0.0.1 -U SA -P Ellie1999 -c -q -t\|

