--Elaheh Toulabi Nejad  9631243
--session6
--Q1 : table creations




CREATE TABLE [Production].[ProductLogs](
	[ProductID] [int],
	[Name] [dbo].[Name],
	[ProductNumber] [nvarchar](25),
	[MakeFlag] [dbo].[Flag],
	[FinishedGoodsFlag] [dbo].[Flag],
	[Color] [nvarchar](15),
	[SafetyStockLevel] [smallint],
	[ReorderPoint] [smallint],
	[StandardCost] [money],
	[ListPrice] [money],
	[Size] [nvarchar](5),
	[SizeUnitMeasureCode] [nchar](3),
	[WeightUnitMeasureCode] [nchar](3),
	[Weight] [decimal](8, 2),
	[DaysToManufacture] [int],
	[ProductLine] [nchar](2),
	[Class] [nchar](2),
	[Style] [nchar](2),
	[ProductSubcategoryID] [int],
	[ProductModelID] [int],
	[SellStartDate] [datetime],
	[SellEndDate] [datetime],
	[DiscontinuedDate] [datetime],
	[rowguid] [uniqueidentifier] ROWGUIDCOL,
	[ModifiedDate] [datetime],
        [TypeOfChange] [nvarchar](32)
)




--example
UPDATE  Production.Product SET Name =' ell  product' WHERE ProductID='1'

SELECT * FROM Production.ProductLogs
