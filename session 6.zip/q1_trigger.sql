--Elaheh Toulabi Nejad  9631243
--session6
--Q1 : Trigger Definition



CREATE TRIGGER [Production].[KeepProductLogs] ON [Production].[Product]
AFTER INSERT,DELETE,UPDATE
AS
BEGIN

  SET NOCOUNT ON;

  if(EXISTS(SELECT * FROM inserted) and  EXISTS(SELECT * FROM deleted))
    BEGIN
        INSERT INTO [Production].[ProductLogs] (
                    [ProductID],
                    [Name],
                    [ProductNumber],
                    [MakeFlag],
                    [FinishedGoodsFlag],
                    [Color],
                    [SafetyStockLevel],
                    [ReorderPoint],
                    [StandardCost],
                    [ListPrice],
                    [Size],
                    [SizeUnitMeasureCode],
                    [WeightUnitMeasureCode],
                    [Weight],
                    [DaysToManufacture],
                    [ProductLine] ,
                    [Class],
                    [Style],
                    [ProductSubcategoryID],
                    [ProductModelID],
                    [SellStartDate],
                    [SellEndDate],
                    [DiscontinuedDate],
                    [rowguid]  ,
                    [ModifiedDate],
                    [TypeOfChange]
        )  
        SELECT d.* FROM ((SELECT inserted.* , TypeOfChange='update' FROM inserted) UNION  (SELECT deleted.* , TypeOfChange='update' FROM deleted))as d
    END


    if(EXISTS(SELECT * FROM inserted) and NOT EXISTS(SELECT * FROM deleted))
    BEGIN
        INSERT INTO [Production].[ProductLogs] (
                    [ProductID],
                    [Name],
                    [ProductNumber],
                    [MakeFlag],
                    [FinishedGoodsFlag],
                    [Color],
                    [SafetyStockLevel],
                    [ReorderPoint],
                    [StandardCost],
                    [ListPrice],
                    [Size],
                    [SizeUnitMeasureCode],
                    [WeightUnitMeasureCode],
                    [Weight],
                    [DaysToManufacture],
                    [ProductLine] ,
                    [Class],
                    [Style],
                    [ProductSubcategoryID],
                    [ProductModelID],
                    [SellStartDate],
                    [SellEndDate],
                    [DiscontinuedDate],
                    [rowguid]  ,
                    [ModifiedDate],
                    [TypeOfChange]
        )  
        SELECT inserted.* , TypeOfChange='insert' FROM inserted
    END

    if( NOT EXISTS(SELECT * FROM inserted) and  EXISTS(SELECT * FROM deleted))
    BEGIN
        INSERT INTO [Production].[ProductLogs] (
                    [ProductID],
                    [Name],
                    [ProductNumber],
                    [MakeFlag],
                    [FinishedGoodsFlag],
                    [Color],
                    [SafetyStockLevel],
                    [ReorderPoint],
                    [StandardCost],
                    [ListPrice],
                    [Size],
                    [SizeUnitMeasureCode],
                    [WeightUnitMeasureCode],
                    [Weight],
                    [DaysToManufacture],
                    [ProductLine] ,
                    [Class],
                    [Style],
                    [ProductSubcategoryID],
                    [ProductModelID],
                    [SellStartDate],
                    [SellEndDate],
                    [DiscontinuedDate],
                    [rowguid]  ,
                    [ModifiedDate],
                    [TypeOfChange]
        )  
        SELECT deleted.* , TypeOfChange='delete' FROM deleted
    END

END





