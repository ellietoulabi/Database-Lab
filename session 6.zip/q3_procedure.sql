--Elaheh Toulabi Nejad	9631243
--session 6
--Q3 : Procedure Creation and Execution

 CREATE PROCEDURE difference_b_tables
 AS
 BEGIN
	 INSERT INTO Production.DifferenceOfTables
				 SELECT * 
				 FROM(SELECT * FROM Production.ProductLogs 
				 EXCEPT 
				 SELECT * FROM Production.ProductLogsCopy) as i
 END


 EXECUTE difference_b_tables

 SELECT * FROM Production.ProductLogs
 SELECT * FROM Production.ProductLogsCopy
 SELECT * FROM Production.DifferenceOfTables