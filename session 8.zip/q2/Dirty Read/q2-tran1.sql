
--1st tran

SELECT * FROM books

-- Transaction 1

BEGIN Tran

UPDATE books set amount = 12
WHERE Id = 1
PRINT '(1)Updted : AMOUNT=12'
SELECT * FROM books

-- Billing the customer
WaitFor Delay '00:00:10'
PRINT '(1)Wait End : Rllback'
ROLLBACK Transaction



SELECT * FROM books
