--2nd tran
BEGIN TRAN
PRINT '(2) WAITING '
WaitFor Delay '00:00:5'
PRINT '(2) Wait End '

SELECT * FROM books
WHERE Id = 1
COMMIT

SELECT * FROM books
