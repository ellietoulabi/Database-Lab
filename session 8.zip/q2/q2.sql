CREATE DATABASE library

USE library

CREATE TABLE books
(
	Id INT PRIMARY KEY,
	Name VARCHAR(50) NOT NULL,
	amount INT NOT NULL

)

INSERT into books

VALUES 
(1, 'Sale Balva', 12),
(2, 'Blindness', 15),
(3, 'Zed', 10)


--1st tran

SELECT * FROM books

-- Transaction 1

BEGIN Tran

UPDATE books set amount = 11
WHERE Id = 1

-- Billing the customer
WaitFor Delay '00:00:10'
Rollback Transaction


--2nd tran