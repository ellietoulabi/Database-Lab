

BEGIN TRANSACTION

WaitFor Delay '00:00:01'

BEGIN TRAN
UPDATE  Sales.Customer
SET     TerritoryID = 1
WHERE   CustomerID = 20
WaitFor Delay '00:00:10'
COMMIT TRAN

BEGIN TRAN
SELECT  *
FROM    Sales.SalesOrderHeader
WHERE   SalesOrderID=43662
COMMIT TRAN

COMMIT
