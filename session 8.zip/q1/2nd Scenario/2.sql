
BEGIN TRANSACTION

    WaitFor Delay '00:00:01'

    BEGIN TRAN
      UPDATE Sales.SalesOrderHeader
      SET
        [OnlineOrderFlag] = 1    
      WHERE SalesOrderID=43662
      WaitFor Delay '00:00:05'
    COMMIT TRAN
    
    BEGIN TRAN
      SELECT *
      FROM    Sales.Customer as c
      WHERE   CustomerID = 20
      WaitFor Delay '00:00:15'
    COMMIT TRAN

    BEGIN TRAN
      UPDATE  Sales.Customer
    SET     TerritoryID = 4
    WHERE   CustomerID = 20
    COMMIT TRAN
 
COMMIT
