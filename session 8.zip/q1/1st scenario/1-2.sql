WHILE 1=1
BEGIN
UPDATE Sales.SalesOrderHeader
      SET
        [OnlineOrderFlag] = 1    
      WHERE SalesOrderID=43662
END



