

WHILE 1=1
BEGIN
    SELECT * FROM Sales.SalesOrderHeader

END