
-- login creation in SQL Server side
CREATE LOGIN new_user2 WITH PASSWORD='1', CHECK_POLICY=OFF

-- chech if query above has executed correctly
SELECT * FROM sys.server_principals

