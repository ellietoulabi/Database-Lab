
--all in SA userspace
USE AdventureWorks2012
Go

CREATE USER myuser2 for login new_user2

CREATE ROLE Role2


--1st solution 
GRANT ALTER ANY ROLE, CREATE ROLE, ALTER ANY APPLICATION ROLE, VIEW DEFINITION
TO Role2
--2nd solution
ALTER ROLE db_securityadmin ADD MEMBER Role2


ALTER ROLE Role2 add member muser3


GRANT SELECT
ON DATABASE::AdventureWorks2012
TO Role2
