
-- login creation in SQL Server side
CREATE LOGIN new_user WITH PASSWORD='1', CHECK_POLICY=OFF

-- chech if query above has executed correctly
SELECT * FROM sys.server_principals

-- role creation
CREATE SERVER ROLE Role1

-- chech if query above has executed correctly
SELECT * FROM sys.server_principals



--grant all priviledges
USE master
GO

GRANT ALTER ANY DATABASE
TO Role1


--add user2 to role1
ALTER SERVER ROLE Role1 ADD member new_user

-- see server logins and their roles to check if command above  has been executed correctly
select sp.name,sp1.name FROM
sys.server_role_members as srm
join sys.server_principals as sp
on srm.member_principal_id = sp.principal_id
join sys.server_principals as sp1
on srm.role_principal_id =  sp1.principal_id



