
--all in SA userspace
CREATE USER muser for login new_user

USE AdventureWorks2012
Go

grant SELECT,INSERT,DELETE,ALTER,UPDATE
on DATABASE::AdventureWorks2012 
to  muser

--all in new_user(muser) userspace
CREATE TABLE testPrmTable
(
    ID      VARCHAR(4),
    name    VARCHAR(20)
);

INSERT INTO testPrmTable
( 
 [ID], [name]
)
VALUES
( 
 '1','el'
),
( 
 '2','mo'
)
GO

SELECT * FROM testPrmTable